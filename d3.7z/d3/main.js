let container = d3.select('#body');

const showData = data => {
    const max = d3.max(data, client => client.Weight);
    const widthScale = d3.scaleLinear()
        .range([0, 300])
        .domain([0, max]);

    const positionScale = d3.scaleBand()
        .domain(data.map(client => client.Name))
        .range([0, 200])
        .padding(0.3);

    const join = container.selectAll('rect').data(data);

    const newElements = join.enter()
        .append('rect')
        .attr('fill', 'blue')
        .attr('stroke', 'white')
        .attr('height', positionScale.bandwidth())
        .attr('transform', d => 'translate(0,0)')
        .on('click', d => {
            d3.select('#name').node().value = d.Name;
            d3.select('#weight').property('value', d.Weight);
        });

    join.merge(newElements).transition()
        .attr('width', client => widthScale(client.Weight))
        .attr('height', positionScale.bandwidth())
        .attr('transform', d => `translate(0,${positionScale(d.Name)})`);

    join.exit().transition().remove();
    // .on('mouseover', function() {
    //     this.style.fill = 'red';
    // })
    // .on('mouseout', function() {
    //     this.style.fill = 'blue';
    // });

    const xAxis = d3.axisBottom(widthScale)
        .ticks(5)
        .tickFormat(tick => tick + ' lb');
    d3.select('#xAxis')
        .attr('transform', 'translate(50, 200)')
        .call(xAxis);

    const yAxis = d3.axisLeft(positionScale);
    d3.select('#yAxis')
        .attr('transform', 'translate(50, 0)')
        .call(yAxis);

    const svgCont = d3.select('#container');
    const line = svgCont
        .append('g')
    // .attr('transform', 'translate(0, 0)');

    line.append('line')
        .attr('x1', 0)
        .attr('x2', 0)
        .attr('y1', 0)
        .attr('y2', 250)
        .attr('stroke', 'red')
        .attr('stroke-width', '3px');

    // svgCont.on('mousemove', function(){
    //     const x = d3.mouse(this)[0];
    //     const y = d3.event.y;
    //
    //     line.attr('transform', `translate(${x},-10)`);
    // });
};

const processData = clients => {
    showData(clients);

    d3.select('#save').on('click', function(){
        const name = d3.select('#name').node().value;
        const weight = d3.select('#weight').node().value;
        const client = clients.find(d => d.Name === name);

        if (client) {
            client.Weight = weight !== '' ? weight : client.Weight;
        } else {
            clients.push({
                'Name': name,
                Weight: weight
            });
        }
        showData(clients);
    });

    d3.select('#min-weight').on('change', function(){
        const value = this.value;
        const filteredData = clients.filter(c => +c.Weight > value);
        showData(filteredData);
    });
};

d3.csv('data.csv').then(processData);
//--------------------------------------------- line
const container1 = d3.select('#body1');
const showData1 = data => {
    const bodyHeight = 200;
    const bodyWidth = 400;

    data = data.map(d => ({
        date: new Date(d.Date),
        price: +d.Count
    }));

    const maxValue = d3.max(data, d => d.price);

    const yScale = d3.scaleLinear()
        .range([bodyHeight, 0])
        .domain([0, maxValue]);

    container1.append('g')
        .call(d3.axisLeft(yScale));

    const xScale = d3.scaleTime()
        .domain(d3.extent(data, d => d.date))
        .range([0, bodyWidth]);

    container1.append('g')
        .attr('transform', 'translate(0, ' + bodyHeight + ')')
        .call(d3.axisBottom(xScale)
            .tickFormat(d3.timeFormat('%b')));

    const valueLine = d3.line()
        .x(d => xScale(d.date))
        .y(d => yScale(d.price))
        // .defined(d => !!d.price);

    container1.append('path')
        .datum(data)
        .attr('d', valueLine)
        .attr('class', 'line');
};

d3.csv('data.csv').then(showData1);
//--------------------------------------------- pie
const body2 = d3.select('#body2');

const showData2 = data => {
    const bodyHeight = 200;
    const bodyWidth = 400;

    data = data.map(d => ({
        country: d.Country,
        sales: +d.Sales
    }));

    const pie = d3.pie().
        value(d => d.sales);

    const colorScale = d3.scaleOrdinal()
        .range(d3.schemeCategory10)
        .domain(data.map(d => d.country));

    const arc = d3.arc()
        .outerRadius(bodyHeight/2)
        .innerRadius(50);
        // pie:.innerRadius(0);
        // donut: .innerRadius(50);

    const g = body2.selectAll('.arc')
        .data(pie(data))
        .enter()
        .append('g');

    g.append('path')
        .attr('d', arc)
        .attr('fill', d => {
            return colorScale(d.data.country)
        })
};

d3.csv('data.csv').then(showData2);
//--------------------------------------------- map
const body3 = d3.select('#body3');

const showData3 = dataSources => {
    const mapInfo = dataSources[1];
    const data = dataSources[0];
    const quakesData = dataSources[2];

    const dataIndex = {};
    data.forEach(item => {
        const country = item.Country;
        dataIndex[country] = +item.Magnitude;
    });

    mapInfo.features = mapInfo.features.map(feature => {
        const country = feature.properties.name;
        const magnitude = dataIndex[country];
        feature.properties.Magnitude = magnitude;
        return feature;
    });

    const maxEarthQuake = d3.max(mapInfo.features, d => d.properties.Magnitude);
    const medianEarthQuake = d3.median(mapInfo.features, d => d.properties.Magnitude);
    const cScale = d3.scaleLinear()
        .domain([0, medianEarthQuake, maxEarthQuake])
        .range(['white', 'orange', 'red']);

    const bodyHeight = 400;
    const bodyWidth = 800;

    const projection = d3.geoMercator()
        .scale(80)
        .translate([bodyWidth/2-100, bodyHeight/2-50]);

    const path = d3.geoPath()
        .projection(projection);

    body3.selectAll('path')
        .data(mapInfo.features)
        .enter()
        .append('path')
        .attr('d', d => path(d))
        .attr('stroke', '#999')
        .attr('fill', d => d.properties.Magnitude ? cScale(d.properties.Magnitude) : 'white');
        // .attr('fill', '#eee');

    body3.selectAll('circle')
        .data(quakesData)
        .enter()
        .append('circle')
        .attr('r', 3)
        .attr('cx', d => projection([+d.Longitude, +d.Latitude])[0])
        .attr('cy', d => projection([+d.Longitude, +d.Latitude])[1])
        .attr('fill', '#0055AA')
        .style('opacity', 0.3)
};

Promise.all([
    d3.csv('countries.data.csv'),
    d3.json('countries.geo.json'),
    d3.csv('quakesData.csv')
]).then(showData3);
//--------------------------------------------- network
const body4 = d3.select('#container4');

const createElements = network => {
    let nodes = body4.append('g')
        .attr('class', 'nodes')
        .selectAll('circle')
        .data(network.nodes)
        .enter()
        .append('circle')
        .attr('r', 5)
        .attr('fill', '#000');

    const links = body4.append('g')
        .attr('class', 'links')
        .selectAll('line')
        .data(network.links)
        .enter()
        .append('line')
        .attr('stroke', '#000')
};

const updateElements = data => {
    d3.select('.nodes')
        .selectAll('circle')
        .attr('cx', d => d.x)
        .attr('cy', d => d.y);

    d3.select('.links')
        .selectAll('line')
        .attr('x1', d => d.source.x)
        .attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x)
        .attr('y2', d => d.target.y)
};

const showData4 = network => {
    const bodyHeight = 100;
    const bodyWidth = 200;

    createElements(network);

    const simulation = d3.forceSimulation()
        .force('link', d3.forceLink().id(d => d.id))
        .force('charge', d3.forceManyBody())
        .force('center', d3.forceCenter(bodyWidth/2, bodyHeight/2));

    simulation.nodes(network.nodes)
        .on('tick', updateElements);
    simulation.force('link').links(network.links);
};

d3.json('network.json').then(showData4);
//--------------------------------------------- tree map
const body5 = d3.select('#container5');

const showData5 = data => {
    const bodyHeight = 200;
    const bodyWidth = 300;

    const treemap = d3.treemap()
        .size([bodyWidth, bodyHeight])
        .paddingInner(2);

    const root = d3.hierarchy(data)
        .sum(d => d.sales);

    treemap(root);

    const cScale = d3.scaleOrdinal(d3.schemeCategory10);

    const cell = body5.selectAll('g')
        .data(root.leaves())
        .enter()
        .append('g')
        .attr('transform', d => `translate(${d.x0},${d.y0})`);

    cell.append('rect')
        .attr('width', d => d.x1 - d.x0)
        .attr('height', d => d.y1 - d.y0)
        .attr('fill', d => cScale(d.parent.data.name));

    cell.append('text')
        .text(d => d.data.name)
        .attr('alignment-baseline', 'hanging')
        .attr('fill', 'white');
};

d3.json('treemap.json').then(showData5);
//--------------------------------------------- brushing & zoom
const container6 = d3.select('#container6');
const body6 = d3.select('#body6');

const isSelected = (coords, x, y) => {
    let x0 = coords[0][0],
        x1 = coords[1][0],
        y0 = coords[0][1],
        y1 = coords[1][1];

    return x0 <= x && x <= x1 && y0 <= y && y <= y1;
};

const showData6 = data => {
    const bodyWidth = 300;
    const bodyHeight = 300;
    const xExten6 = d3.extent(data, d => +d.Weight);
    const xScale6 = d3.scaleLinear().range([0, bodyWidth])
        .domain([xExten6[0]-5, xExten6[1]+5]);
    const yExtent6 = d3.extent(data, d => +d.Height)
    const yScale6 = d3.scaleLinear().range([0, bodyHeight])
        .domain([yExtent6[0]-5, yExtent6[1]+5]);

    const join = body6.selectAll("circle")
        .data(data);

    const newelements6 = join.enter()
        .append("circle")
        .style("fill", "blue")
        .style("r", "5");

    join.merge(newelements6)
        .transition()
        .attr("cx", d => xScale6(+d.Weight))
        .attr("cy", d => yScale6(+d.Height));

    const yAxis6 = d3.axisLeft(yScale6);
    const yAxisGroup6 = d3.select("#yAxis6")
        .style("transform", "translate(40px, 10px)")
        .call(yAxis6);

    const xAxis6 = d3.axisBottom(xScale6);
    const xAxisGroup6 = d3.select("#xAxis6")
        .style("transform", `translate(40px, ${bodyHeight+10}px)`)
        .call(xAxis6);

    // ------ Zoom
    const zoom = d3.zoom();
    zoom.on('zoom', function(){
        const newXScale = d3.event.transform.rescaleX(xScale6);
        const newYScale = d3.event.transform.rescaleY(yScale6);

        xAxis6.scale(newXScale);
        xAxisGroup6.call(xAxis6);

        yAxis6.scale(newYScale);
        yAxisGroup6.call(yAxis6);

        join.merge(newelements6)
            .attr('cx', d => newXScale(+d.Weight))
            .attr('cy', d => newYScale(+d.Height));
    });
    container6.call(zoom);
};

d3.csv('data.csv').then(data => {
    showData6(data);

    const brush = d3.brush();
    brush.on('brush', function(){
        const coords = d3.event.selection;
        body6.selectAll('circle')
            .style('fill', function() {
                const cx = d3.select(this).attr('cx');
                const cy = d3.select(this).attr('cy');
                const selected = isSelected(coords,cx,cy);
                return selected ? 'red' : 'blue';
            });
    });

    body6.append('g').attr('class', 'brush')
        .call(brush);
});
//--------------------------------------------- tooltip
const barchart = d3.select("#barchart");
const width = 300;
const height = 200;
let selectedCountry;

barchart.attr('height', height);
barchart.attr('width', width);

const showTooltip = (text, coords) => {
    d3.select('#tooltip-container')
        .text(text)
        .style('top', (coords[1]-height)+'px')
        .style('left', (coords[0]-5)+'px')
        .style('display', 'block');
};

const drawBarChart = data => {
    const margin = { left: 20, bottom: 20, right: 20, top: 20 };

    const bodyWidth = width - margin.left - margin.right;
    const bodyHeight = height - margin.top - margin.bottom;

    const xScale = d3.scaleBand()
        .range([0, bodyWidth])
        .domain(data.map(d => d.Country))
        .padding(0.2)

    const yScale = d3.scaleLinear()
        .range([bodyHeight, 0])
        .domain([0, d3.max(data, d => d.GDP)]);

    const barChartBody = barchart.select(".barchart-body")
        .attr("transform", `translate(${margin.left},${margin.bottom})`)
        .selectAll("rect")
        .data(data);

    barChartBody.enter()
        .append("rect")
        .attr("width", xScale.bandwidth())
        .attr("height", d => bodyHeight - yScale(d.GDP))
        .attr("y", d => yScale(d.GDP))
        .attr("x", d => xScale(d.Country))
        .on('mouseenter', d => showTooltip(d.Country, [d3.event.clientX, d3.event.clientY]))
        .on('mousemove', d => showTooltip(d.Country, [d3.event.clientX, d3.event.clientY]))
        .on('mouseleave', d => {
            d3.select('#tooltip-container')
                .style('display', 'none');
        })
        .on('click', d => {
            selectedCountry = d.Country;
            drawBarChart(data);
        })
        .merge(barChartBody)
        .attr("fill", d => selectedCountry === d.Country ? 'red' : '#556677');
};

d3.csv("tooltip.csv").then(data => {
    data = data.map(d =>{
        d.GDP = +d.GDP;
        return d;
    });
    selectedCountry = data[0].Country;
    drawBarChart(data)
});
//--------------------------------------------- linked views
let barchart1 = d3.select("#barchart1")
let timeline = d3.select("#timeline")
const width1 = 300;
const height1 = 200;
let selectedCountry1;

barchart1.attr('height', height1);
barchart1.attr('width', width1);
timeline.attr("height", height1);
timeline.attr("width", width1);

const showTooltip1 = (text, coords) => {
    d3.select('#tooltip-container1')
        .text(text)
        .style('top', (coords[1]-370)+'px')
        .style('left', (coords[0]-5)+'px')
        .style('display', 'block');
};

const drawLineChart = data => {
    data = data.history;
    let margin = { left: 40, bottom: 20, right: 20, top: 20 }

    let bodyWidth = width1 - margin.left - margin.right;
    let bodyHeight = height1 - margin.top - margin.bottom;

    let xScale = d3.scaleLinear()
        .range([0, bodyWidth])
        .domain(d3.extent(data, d => d.year))

    let yScale = d3.scaleLinear()
        .range([bodyHeight, 0])
        .domain([0, d3.max(data, d => d.value)])

    let lineGenerator = d3.line()
        .x(d => xScale(d.year))
        .y(d => yScale(d.value))

    timeline.select(".timeline-body")
        .attr("transform", `translate(${margin.left},${margin.top})`)
        .select("path").datum(data)
        .attr('fill', 'none')
        .attr("d", lineGenerator)

    timeline.select(".timeline-xAxis")
        .attr("transform", `translate(${margin.left},${height - margin.bottom})`)
        .call(d3.axisBottom(xScale).ticks(5))

    timeline.select(".timeline-yAxis")
        .attr("transform", `translate(${margin.left},${margin.top})`)
        .call(d3.axisLeft(yScale).ticks(5).tickFormat(d => (d / 1e12) + "T"))

};

const drawBarChart1 = data => {
    const margin = { left: 20, bottom: 20, right: 20, top: 20 };

    const bodyWidth = width1 - margin.left - margin.right;
    const bodyHeight = height1 - margin.top - margin.bottom;

    const xScale = d3.scaleBand()
        .range([0, bodyWidth])
        .domain(data.map(d => d.Country))
        .padding(0.2);

    let yScale = d3.scaleLinear()
        .range([bodyHeight, 0])
        .domain([0, d3.max(data, d => d[2016])]);

    const barChartBody = barchart1.select(".barchart-body1")
        .attr("transform", `translate(${margin.left},${margin.bottom})`)
        .selectAll("rect")
        .data(data);

    barChartBody.enter()
        .append("rect")
        .attr("width", xScale.bandwidth())
        .attr("height", d => bodyHeight - yScale(d[2016]))
        .attr("y", d => yScale(d[2016]))
        .attr("x", d => xScale(d.Country))
        .on("mouseenter", (d) => {
            showTooltip1(d.Country, [d3.event.clientX, d3.event.clientY])
        })
        .on("mousemove", (d) => {
            showTooltip1(d.Country, [d3.event.clientX, d3.event.clientY + 30])
        })
        .on("mouseleave", (d) => {
            d3.select("#tooltip").style("display", "none")
        })
        .on('click', d => {
            selectedCountry = d.Country;
            drawBarChart1(data);
            drawLineChart(d);
        })
        .merge(barChartBody)
        .attr("fill", d => selectedCountry === d.Country ? 'red' : '#556677');
};

const prepareData = data => {
    return data.map(d => {
        const years = Object.keys(d).filter(k => !isNaN(+k));
        const history = years.map(y => ({
            year: y,
            value: +d[y]
        }));
        d.history = history;
        d[2016] = +d[2016];
        return d;
    });
};

d3.csv('linkedViews.csv').then(data => {
    data = prepareData(data);
    selectedCountry1 = data[0].Country;
    drawBarChart1(data);
    drawLineChart(data[0]);
});












