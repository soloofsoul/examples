let anime = {
    audio: undefined,
    timeConfig: undefined,
    elements: [
        'hand',
        'fatherHead',
        'motherHead',
        'brotherHead',
        'sisterHead',
        'dytiaHead',
        'father',
        'mother',
        'brother',
        'sister',
        'dytia'
    ],
    domElements: {},
    sunEl: undefined,
    init: function(pathToMp3, timeConfig){
        this.audio = new Audio(pathToMp3);
        this.audio.addEventListener('play', this.playHandler.bind(this));
        this.audio.addEventListener('ended', function() {
            this.currentTime = 0;
            this.play();
        }, false);
        this.timeConfig = timeConfig;

        this.sunEl = document.getElementById('sun');

        let domElForEachFn = elementId => {
            this.domElements[elementId] = document.getElementById(elementId);
        };
        this.elements.forEach(domElForEachFn);
    },
    run: function(){
        this.audio.play();
        // this.playHandler();
    },
    playHandler: function() {
        this.elements.forEach(this.processElement.bind(this));

        setTimeout(() => { this.sunEl.className = 'sunAnimate'; }, 2000);
    },
    processElement: function(elementId){
        let elementConfig = this.timeConfig[elementId];
        let tmpCamelCaseElId = `${elementId.charAt(0).toUpperCase()}${elementId.slice(1)}`;
        let cssConfig = {
            hideClass: `hide${tmpCamelCaseElId}`,
            showClass: `show${tmpCamelCaseElId}`
        };

        elementConfig.show.forEach(this.processShowHide.bind(
            this,
            this.domElements[elementId],
            cssConfig,
            elementConfig.animationDuration
        ));
    },
    processShowHide: function(domElement, cssConfig, animationDuration, showConfig){
        this.showElement(domElement, cssConfig, showConfig.at);

        let hideAt = showConfig.at + animationDuration + showConfig.during;
        this.hideElement(domElement, cssConfig, hideAt);
    },
    showElement: function(domElement, cssConfig, at){
        setTimeout(() => {
            domElement.classList.remove(cssConfig.hideClass);
            domElement.classList.add(cssConfig.showClass);
        }, at*1000);
    },
    hideElement: function(domElement, cssConfig, at){
        setTimeout(() => {
            domElement.classList.remove(cssConfig.showClass);
            domElement.classList.add(cssConfig.hideClass);
        }, at*1000);
    }
};

let pathToMp3 = 'file/song.mp3';
let timeConfig = {
    hand: {
        animationDuration: 2,
        show: [
            { at: 5, during: 3 }, // tato
            { at: 15, during: 3 }, // mama
            { at: 23, during: 3 }, // bratyk
            { at: 32, during: 3 }, // sestra
            { at: 40, during: 3 }, // dytia
            { at: 53, during: 3 }, // tato
            { at: 62, during: 3 }, // mama
            { at: 71, during: 3 }, // bratyk
            { at: 79, during: 3 }, // sestra
            { at: 88, during: 3 } // dytia
        ]
    },
    fatherHead: {
        animationDuration: 2,
        show: [
            { at: 5, during: 3 }, // tato
            { at: 53, during: 3 } // tato
        ]
    },
    motherHead: {
        animationDuration: 2,
        show: [
            { at: 15, during: 3 }, // mama
            { at: 62, during: 3 }, // mama
        ]
    },
    brotherHead: {
        animationDuration: 2,
        show: [
            { at: 23, during: 3 }, // bratyk
            { at: 71, during: 3 }, // bratyk
        ]
    },
    sisterHead: {
        animationDuration: 2,
        show: [
            { at: 32, during: 3 }, // sestra
            { at: 79, during: 3 }, // sestra
        ]
    },
    dytiaHead: {
        animationDuration: 2,
        show: [
            { at: 40, during: 3 }, // dytia
            { at: 88, during: 3 } // dytia
        ]
    },
    father: {
        animationDuration: 2,
        show: [
            { at: 2, during: 6 }, // tato
            { at: 50, during: 6 } // tato
        ]
    },
    mother: {
        animationDuration: 2,
        show: [
            { at: 11, during: 7 }, // mama
            { at: 59, during: 7 }, // mama
        ]
    },
    brother: {
        animationDuration: 2,
        show: [
            { at: 20, during: 6 }, // bratyk
            { at: 68, during: 6 }, // bratyk
        ]
    },
    sister: {
        animationDuration: 2,
        show: [
            { at: 28, during: 7 }, // sestra
            { at: 76, during: 7 }, // sestra
        ]
    },
    dytia: {
        animationDuration: 2,
        show: [
            { at: 37, during: 6 }, // dytia
            { at: 85, during: 6 } // dytia
        ]
    }
};
anime.init(pathToMp3, timeConfig);
anime.run();